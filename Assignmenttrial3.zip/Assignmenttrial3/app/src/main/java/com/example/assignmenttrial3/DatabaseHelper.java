package com.example.assignmenttrial3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "food_order.db";
    private static final int DATABASE_VERSION = 1;

    // Food Items Table
    public static final String TABLE_FOOD_ITEMS = "food_items";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_COST = "cost";

    // Order Plans Table
    public static final String TABLE_ORDER_PLANS = "order_plans";
    public static final String COL_ORDER_ID = "order_id";
    public static final String COL_DATE = "date";
    public static final String COL_TARGET_COST = "target_cost";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createFoodItemsTable = "CREATE TABLE " + TABLE_FOOD_ITEMS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_COST + " REAL)";
        db.execSQL(createFoodItemsTable);

        String createOrderPlansTable = "CREATE TABLE " + TABLE_ORDER_PLANS + " (" +
                COL_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DATE + " TEXT, " +
                COL_TARGET_COST + " REAL)";
        db.execSQL(createOrderPlansTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOOD_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDER_PLANS);
        onCreate(db);
    }

    public void initializeData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_FOOD_ITEMS, null);
        cursor.moveToFirst();
        int count = cursor.getInt(0);
        cursor.close();

        if (count == 0) {
            db.execSQL("INSERT INTO food_items (name, cost) VALUES ('Pizza', 12.99)");
            db.execSQL("INSERT INTO food_items (name, cost) VALUES ('Burger', 9.99)");
            // Add more food items here...
        }
    }

    public Cursor getAllFoodItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_FOOD_ITEMS, null);
    }

    public void insertOrderPlan(String date, double targetCost) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_TARGET_COST, targetCost);
        db.insert(TABLE_ORDER_PLANS, null, values);
    }

    public Cursor getOrderPlan(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ORDER_PLANS + " WHERE date = ?", new String[]{date});
    }
}
