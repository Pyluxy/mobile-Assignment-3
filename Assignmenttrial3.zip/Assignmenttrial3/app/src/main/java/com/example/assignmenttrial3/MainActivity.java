package com.example.assignmenttrial3;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etTargetCost, etDate;
    private Button btnSavePlan, btnQueryPlan;
    private RecyclerView rvFoodItems;

    private com.example.assignmenttrial3.DatabaseHelper dbHelper;
    private com.example.assignmenttrial3.FoodAdapter foodAdapter;
    private List<com.example.assignmenttrial3.FoodItem> foodList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        etTargetCost = findViewById(R.id.etTargetCost);
        etDate = findViewById(R.id.etDate);
        btnSavePlan = findViewById(R.id.btnSavePlan);
        btnQueryPlan = findViewById(R.id.btnQueryPlan);
        rvFoodItems = findViewById(R.id.rvFoodItems);

        // Initialize database helper
        dbHelper = new com.example.assignmenttrial3.DatabaseHelper(this);

        // Populate database with default data
        dbHelper.initializeData();

        // Load food items into RecyclerView
        loadFoodItems();

        // Set up RecyclerView
        foodAdapter = new com.example.assignmenttrial3.FoodAdapter(foodList);
        rvFoodItems.setLayoutManager(new LinearLayoutManager(this));
        rvFoodItems.setAdapter(foodAdapter);

        // Save Order Plan button
        btnSavePlan.setOnClickListener(v -> saveOrderPlan());

        // Query Order Plan button
        btnQueryPlan.setOnClickListener(v -> queryOrderPlan());
    }

    private void loadFoodItems() {
        foodList = new ArrayList<>();
        Cursor cursor = dbHelper.getAllFoodItems();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COL_ID));
                String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_NAME));
                double cost = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COL_COST));
                foodList.add(new FoodItem(id, name, cost));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void saveOrderPlan() {
        String targetCostStr = etTargetCost.getText().toString().trim();
        String date = etDate.getText().toString().trim();

        if (targetCostStr.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "Please enter target cost and date", Toast.LENGTH_SHORT).show();
            return;
        }

        double targetCost = Double.parseDouble(targetCostStr);
        dbHelper.insertOrderPlan(date, targetCost);
        Toast.makeText(this, "Order plan saved!", Toast.LENGTH_SHORT).show();
    }

    private void queryOrderPlan() {
        String date = etDate.getText().toString().trim();

        if (date.isEmpty()) {
            Toast.makeText(this, "Please enter a date to query", Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor cursor = dbHelper.getOrderPlan(date);

        if (cursor.moveToFirst()) {
            double targetCost = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COL_TARGET_COST));
            Toast.makeText(this, "Plan for " + date + ": Target Cost = $" + targetCost, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "No plan found for this date", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }
}
